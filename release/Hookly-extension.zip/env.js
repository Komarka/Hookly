window.HooklyEnv = {
  GROQ_API_KEY: "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"
};
